#/bin/sh
cp *.ttf ~/Library/Fonts/
